#pragma once
#include <cstdint>

class Subset
{
public:
	int from = -1;
	int vertex;
	int cost = INT32_MAX;
};

